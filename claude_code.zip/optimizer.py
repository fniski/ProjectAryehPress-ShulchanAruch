"""
Page optimizer for Shulchan Aruch layout.

The page layout has this vertical structure in the center area:

  ┌──────────────────────────────┐
  │  TITLE ROW (fixed height)    │
  ├──────────────────────────────┤
  │  MAIN TEXT (variable)        │
  ├──────────────┬───────────────┤
  │  TAZ         │ MAGEN AVRAHAM │
  ├──────────────┴───────────────┤
  │  MACHATZIT L │ MACHATZIT R   │
  ├──────────────┬───────────────┤
  │  MISHB. ZAH. │ ESHEL AVR.   │
  └──────────────┴───────────────┘

Side columns (Beer HaGolah, Biur HaGra, etc.) run the full
page height independently.

Feasibility = center bands stack within page height
            AND each side column fits within page height.
"""

from dataclasses import dataclass, field
from data import Siman, Seif, CommentaryEntry
from zones import (
    FontConfig, PageGeometry, DEFAULT_GEOMETRY,
    FONT_MAIN, FONT_COMMENTARY_LARGE, FONT_COMMENTARY_SMALL, FONT_SIDE,
)
from measure import measure_height_heuristic, MeasureConfig


def _to_hebrew_letter(n: int) -> str:
    if n <= 0:
        return str(n)
    letters = "אבגדהוזחטיכלמנסעפצקרשת"
    if n <= len(letters):
        return letters[n - 1]
    return str(n)


def concat_main_text(seifim: list[Seif]) -> str:
    parts = []
    for s in seifim:
        parts.append(f"({_to_hebrew_letter(s.seif)})")
        parts.append(s.mechaber)
        if s.rema:
            parts.append(f"הגה: {s.rema}")
    return " ".join(parts)


def concat_commentary(entries: list[CommentaryEntry]) -> str:
    if not entries:
        return ""
    parts = []
    for e in entries:
        parts.append(f"({_to_hebrew_letter(e.seif_katan)}) {e.text}")
    return " ".join(parts)


def split_commentary_half(entries: list[CommentaryEntry]) -> tuple[str, str]:
    if not entries:
        return "", ""
    texts = [f"({_to_hebrew_letter(e.seif_katan)}) {e.text}" for e in entries]
    total_len = sum(len(t) for t in texts)
    half_target = total_len / 2
    left_parts, right_parts = [], []
    running, split_done = 0, False
    for t in texts:
        if not split_done and running + len(t) <= half_target:
            left_parts.append(t)
            running += len(t)
        else:
            split_done = True
            right_parts.append(t)
    return " ".join(left_parts), " ".join(right_parts)


@dataclass
class BandHeights:
    title: float = 36.0
    main_text: float = 0.0
    taz_ma: float = 0.0
    machatzit: float = 0.0
    pri_megadim: float = 0.0
    gap: float = 7.0

    @property
    def total_center_height(self) -> float:
        bands = [self.title, self.main_text]
        if self.taz_ma > 0:
            bands.append(self.taz_ma)
        if self.machatzit > 0:
            bands.append(self.machatzit)
        if self.pri_megadim > 0:
            bands.append(self.pri_megadim)
        num_gaps = len(bands) - 1
        return sum(bands) + num_gaps * self.gap


@dataclass
class PageContent:
    page_num: int
    seif_start: int
    seif_end: int
    zone_texts: dict[str, str] = field(default_factory=dict)
    band_heights: BandHeights = field(default_factory=BandHeights)


@dataclass
class PagePlan:
    siman: int
    pages: list[PageContent] = field(default_factory=list)


def _measure(text: str, width_pt: float, font: FontConfig) -> float:
    return measure_height_heuristic(text, width_pt, font)


def check_page_feasibility(
    siman: Siman,
    seif_start: int,
    seif_end: int,
    geom: PageGeometry,
) -> tuple[bool, dict[str, str], BandHeights]:
    tw = geom.text_width_pt
    th = geom.text_height_pt
    gap = geom.column_gap_pt

    side_width = tw * 0.10
    center_width = tw * 0.80 - 2 * gap
    half_center = (center_width - gap) / 2.0
    pm_left_w = center_width * 0.40 - gap / 2
    pm_right_w = center_width * 0.60 - gap / 2

    # Assemble text
    seifim = siman.get_main_text_for_seifim(seif_start, seif_end)
    zone_texts: dict[str, str] = {}
    zone_texts["main_text"] = concat_main_text(seifim)

    for name in ["taz", "magen_avraham", "mishbetzot_zahav", "eshel_avraham",
                  "beer_hagolah", "biur_hagra", "ateret_zekeinim",
                  "chidushei_rav_akiva_eiger"]:
        entries = siman.get_commentary_for_seifim(name, seif_start, seif_end)
        zone_texts[name] = concat_commentary(entries)

    machatzit_entries = siman.get_commentary_for_seifim(
        "machatzit_hashekel", seif_start, seif_end
    )
    left_m, right_m = split_commentary_half(machatzit_entries)
    zone_texts["machatzit_hashekel_left"] = left_m
    zone_texts["machatzit_hashekel_right"] = right_m

    # Measure bands
    bands = BandHeights()
    bands.main_text = _measure(zone_texts["main_text"], center_width, FONT_MAIN)

    h_taz = _measure(zone_texts["taz"], half_center, FONT_COMMENTARY_LARGE)
    h_ma = _measure(zone_texts["magen_avraham"], half_center, FONT_COMMENTARY_LARGE)
    bands.taz_ma = max(h_taz, h_ma)

    h_ml = _measure(zone_texts["machatzit_hashekel_left"], half_center, FONT_COMMENTARY_SMALL)
    h_mr = _measure(zone_texts["machatzit_hashekel_right"], half_center, FONT_COMMENTARY_SMALL)
    bands.machatzit = max(h_ml, h_mr)

    h_mz = _measure(zone_texts["mishbetzot_zahav"], pm_left_w, FONT_COMMENTARY_SMALL)
    h_ea = _measure(zone_texts["eshel_avraham"], pm_right_w, FONT_COMMENTARY_SMALL)
    bands.pri_megadim = max(h_mz, h_ea)

    center_fits = bands.total_center_height <= th

    # Side columns
    h_beer = _measure(zone_texts["beer_hagolah"], side_width, FONT_SIDE)
    h_biur = _measure(zone_texts["biur_hagra"], side_width, FONT_SIDE)
    left_fits = (h_beer + h_biur + gap) <= th

    h_ateret = _measure(zone_texts["ateret_zekeinim"], side_width, FONT_SIDE)
    h_rae = _measure(zone_texts["chidushei_rav_akiva_eiger"], side_width, FONT_SIDE)
    right_fits = (h_ateret + h_rae + gap) <= th

    feasible = center_fits and left_fits and right_fits
    return feasible, zone_texts, bands


def optimize_page(
    siman: Siman,
    seif_start: int,
    geom: PageGeometry = DEFAULT_GEOMETRY,
) -> PageContent:
    max_seif = siman.num_seifim
    if seif_start > max_seif:
        return PageContent(page_num=0, seif_start=seif_start, seif_end=seif_start)

    lo = seif_start
    hi = max_seif
    best_end = seif_start
    best_texts: dict[str, str] = {}
    best_bands = BandHeights()

    while lo <= hi:
        mid = (lo + hi) // 2
        feasible, zone_texts, bands = check_page_feasibility(siman, seif_start, mid, geom)
        if feasible:
            best_end = mid
            best_texts = zone_texts
            best_bands = bands
            lo = mid + 1
        else:
            hi = mid - 1

    if best_end < seif_start:
        best_end = seif_start
        _, best_texts, best_bands = check_page_feasibility(siman, seif_start, seif_start, geom)

    return PageContent(
        page_num=0,
        seif_start=seif_start,
        seif_end=best_end,
        zone_texts=best_texts,
        band_heights=best_bands,
    )


def optimize_siman(
    siman: Siman,
    geom: PageGeometry = DEFAULT_GEOMETRY,
    measure_config: MeasureConfig | None = None,
) -> PagePlan:
    plan = PagePlan(siman=siman.siman)
    current_seif = 1
    page_num = 1

    while current_seif <= siman.num_seifim:
        page = optimize_page(siman, current_seif, geom)
        page.page_num = page_num
        plan.pages.append(page)

        ch = page.band_heights.total_center_height
        mh = geom.text_height_pt
        print(f"  Page {page_num}: seifim {page.seif_start}-{page.seif_end} "
              f"(center: {ch:.0f}/{mh:.0f} pt)")

        current_seif = page.seif_end + 1
        page_num += 1

    return plan
